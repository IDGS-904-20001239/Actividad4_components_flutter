//Código que facilita el uso de los archivos mediante la importación. 
export 'package:actividad4_componentes/screen/home_screen.dart';
export 'package:actividad4_componentes/screen/jugadores_screen.dart';
export 'package:actividad4_componentes/screen/listview_build_screen.dart';
export 'package:actividad4_componentes/screen/equipos_screen.dart';
export '../screen/error_screen.dart';
export 'package:actividad4_componentes/widgets/drawer_widget.dart';
export 'package:actividad4_componentes/widgets/card_widget.dart';
export '../screen/tarjetas_screen.dart';
export 'package:actividad4_componentes/screen/layout_screen.dart';
export 'package:actividad4_componentes/screen/descripcion_producto_screen.dart';
import 'package:actividad4_componentes/screen/grid_screen.dart';

