import 'package:actividad4_componentes/routers/app_routers.dart';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import '../theme/app_themes.dart';

class HomeScreen extends StatelessWidget {
   
  const HomeScreen({Key? key}) : super(key: key);
  
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      //Barra de arriba de la aplicación. El title ocupa un wiget de tipo text
      appBar: AppBar(title: const Center(child: Text("Actividad 4"))
      ),
      //Esta línea define el cuerpo (body) de un widget ListView.separated.
      //Un ListView.separated es un widget que muestra una lista de elementos con separadores entre ellos.
      body: ListView.separated(
        //Esta línea establece el número de elementos en la lista.
        itemCount: AppRouters.menu.length, 
        //Esta línea define un separador entre cada elemento de la lista.
        separatorBuilder: (BuildContext context, int index) => const Divider(),
        //Esta línea define cómo se construye cada elemento de la lista.
        itemBuilder: (BuildContext context, int index) {
          //Esta línea devuelve un widget ListTile para representar cada elemento de la lista.
          return  ListTile(
            //Esta línea establece el icono
              leading: AppRouters.menu[index]['icon'],
              //Esta línea establece el título
        title: Text(AppRouters.menu[index]['name']),
        //Esta línea establece una función
        onTap: () {
          //Navegar a la ruta asociada al elemento de menú 
          Navigator.pushNamed(context, AppRouters.menu[index]['router']);
          //Imprime un mensaje en la consola 
          print("Acabo de dar un Tap en el ListView Build");
        });
       },
      ),
      );
  }
}
