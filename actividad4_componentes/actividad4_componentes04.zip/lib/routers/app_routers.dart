import 'package:flutter/material.dart';

import '../model/menu_options_model.dart';

import '../screen/screen.dart';

class AppRouters{
  static Map<String, StatelessWidget Function(BuildContext context)> routes = {
    //Esta línea define la ruta principal ("/") en el mapa de rutas.
    //Se crea una instancia de la clase y se devuelve
        '/':(BuildContext context) => const HomeScreen(),
        //Esta línea define la ruta "/ListView" en el mapa de rutas.
        //Se crea una instancia de la clase y se devuelve
        '/ListView':(BuildContext context) => const ListViewBuildScreen(),
        //Esta línea define la ruta "/Jugador" en el mapa de rutas.
        //Se crea una instancia de la clase y se devuelve
        '/Jugador':(BuildContext context) => const JugadorScreen(),
        //Esta línea define la ruta "/Equipos" en el mapa de rutas.
        //Se crea una instancia de la clase y se devuelve
        '/Equipos':(BuildContext context) => const EquipoScreen(),
        '/Tarjetas':(BuildContext context) => const CardScreen(),

      };
    //Declara una variable estática llamada initialRouters y le asigna el valor "/". 
    //Esta variable representa la ruta inicial de la aplicación.
  static String initialRouters='/';
  //Esta línea declara una variable estática llamada menu, que es una lista de mapas.
  //Cada mapa dentro de la lista representa un elemento de menú en la aplicación.
  //Cada mapa tiene tres claves: 'router' (cadena que representa una ruta), 'name' (nombre del elemento de menú) y 'icon' (un ícono asociado al elemento de menú).
  static List<Map<String, dynamic>> menu = [
    
    {
      'router':'/',
      'name': 'home',
      'icon': const Icon(Icons.home)
    },
    //Representa un elemento de menú con la ruta '/ListView', el nombre
    {
      'router':'/ListView',
      'name': 'list2',
      'icon': Icon(Icons.account_balance)
    },
    //Representa un elemento de menú con la ruta '/Jugador', el nombre
    {
      'router':'/Jugador',
      'name': 'list3',
      'icon': Icon(Icons.list_alt_rounded)

    },
    {
      'router':'/Tarjetas',
      'name': 'list4',
      'icon': Icon(Icons.card_membership)

    }
  ]; 
  //declara una lista final llamada menuOptions que contiene elementos del tipo MenuOption. 
  //Cada elemento de la lista es una instancia de la clase MenuOption con valores específicos 
  //para las propiedades 
  static final menuOptions = <MenuOption>[
    MenuOption(router: '/', icon: Icons.home, name: 'Home'),
    MenuOption(router: '/ListView', icon: Icons.power, name: 'ListView'),
    MenuOption(router: '/Jugador', icon: Icons.light, name: 'list3'),
    MenuOption(router: '/Tarjetas', icon: Icons.light, name: 'list4'),
    
  ];
  // declara un método estático llamado onGenarteRouter que toma un parámetro llamado settings. 
  //Este método se utiliza para generar una ruta de navegación en función de los ajustes recibidos.
  static onGenarteRouter(settings) {
    //devuelve una nueva instancia de MaterialPageRoute
    return MaterialPageRoute(builder: (context) => const ErrorScreen());
  }
  
}