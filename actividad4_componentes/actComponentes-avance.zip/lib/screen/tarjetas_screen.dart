import 'package:actividad4_componentes/theme/app_themes.dart';
import 'package:flutter/material.dart';

import 'screen.dart';

class CardScreen extends StatelessWidget {
   
  const CardScreen({Key? key}) : super(key: key);
  
  @override
  Widget build(BuildContext context) {
  
    return Scaffold(
      //Define la barra de aplicación
      appBar: AppBar(
        title: const Center(child: Text('Tarjetas')),
      ),
      //Establece el widget DawerWidget como el cajón lateral derecho de la pantalla.
      endDrawer: const DawerWidget(),
      body: Padding(
        //Establece un espacio de relleno (padding) de 15 píxeles en dirección horizontal y 8 píxeles en dirección vertical alrededor del widget principal.
        padding: const EdgeInsets.symmetric(horizontal: 15,vertical: 8),
        //Contenedor vertical para organizar varios widgets.
        child: Column(
          children: [
            //Comienza la definición de un widget de tarjeta
            Card(
              //Establece el nivel de elevación de la tarjeta
              elevation: 5,
              child: Column(
                      children: [
                        //Definición de un widget de ListTile
                        ListTile(
                          //Define un ícono de álbum de fotos como el elemento líder (izquierda) del ListTile, 
                          //con un color específico.
                          leading: Icon(Icons.photo_album, color: AppThemes.primary4),
                          //Establece el texto del título del ListTile.
                          title: Text('Titulo de la Trajeta'),
                          //Establece el texto del subtítulo del ListTile.
                          subtitle: Text('There are many variations of passages of Lorem Ipsum available, but the majority have suffered alteration in some form, by injected humour, or randomised words which dont look even slightly believable. If you are going to use a passage of Lorem Ipsum, you need to be sure there isnt anything embarrassing hidden in the middle of text. All the Lorem Ipsum generators on the Internet tend to repeat predefined chunks as necessary, making this the first true generator on the Internet. It uses a dictionary of over 200 Latin words, combined with a handful of model sentence structures, to generate Lorem Ipsum which looks reasonable. The generated Lorem Ipsum is therefore always free from repetition, injected humour, or non-characteristic words etc.'),
                        ),
                        //Definición de un widget de fila, que es un contenedor horizontal para organizar varios widgets.
                        Row(
                          //Establece la alineación principal de los widgets hijos de la fila, en este caso, hacia el final (derecha).
                          mainAxisAlignment: MainAxisAlignment.end,
                          children: [
                            //Define un botón de texto con el texto "Soy el boton 1" y una función de retroalimentación vacía (onPressed).
                            TextButton(onPressed: (){}, child: Text('Soy el boton 1')),
                            //Esta línea define otro botón de texto con el texto "Soy el boton 2" y una función de retroalimentación vacía (onPressed).
                            TextButton(onPressed: (){}, child: Text('Soy el boton 2'))
                          ],
                          ),
                        ],
              ),
            ),
          ],
        ),
      ),
      );
  }
}