import 'package:cached_network_image/cached_network_image.dart';
import 'package:flutter/material.dart';
import 'screen.dart';
import 'package:actividad4_componentes/routers/app_routers.dart';

class LayoutScreen extends StatelessWidget {
   
  const LayoutScreen({Key? key}) : super(key: key);
  
  @override
  Widget build(BuildContext context) {
     List<Map<String, dynamic>> productos = AppRouters.productos ;
    return Scaffold(
      //Define la barra de aplicación
      appBar: AppBar(
        title: const Center(child: Text('Tarjetas')),
      ),
      //Establece el widget DawerWidget como el cajón lateral derecho de la pantalla.
      endDrawer: const DawerWidget(),
      body: ListView.separated(
        itemCount: productos.length,
        itemBuilder: (BuildContext context,int  index){
          return ListTile(
            title: Text(productos[index]['Titulo']),
            subtitle: Image.network(productos[index]['Imagenes']
            ),
        );
  
        },
        separatorBuilder: (BuildContext context, int index)
        {return const Divider();}
       ),
    );
  }
}