import 'package:flutter/material.dart';

import '../screen/screen.dart';

class DescripcionPScreen extends StatelessWidget {
   
  const DescripcionPScreen({Key? key}) : super(key: key);
  
  @override
  Widget build(BuildContext context) {
     return Scaffold(
      //Define la barra de aplicación
      appBar: AppBar(
        title: const Center(child: Text('Tarjetas')),
      ),
      //Establece el widget DawerWidget como el cajón lateral derecho de la pantalla.
      endDrawer: const DawerWidget(),
      body: (
        Text('Descripción Producto Screen')
       ),
    );
  }
}