import 'package:flutter/material.dart';

class AppThemes{
  //Define la configuración de temas y estilos para la interfaz de usuario de la aplicación.
  static ThemeData themes = ThemeData(
    //Clase que define un conjunto de colores predefinidos para la interfaz de usuario. 
    //fromSeed es un método estático de ColorScheme que permite generar un esquema de colores a partir de un color 
        colorScheme: ColorScheme.fromSeed(seedColor: Colors.deepPurple),
        //Habilita el uso de Material 3 en la aplicación.
        useMaterial3: true,
      );

}