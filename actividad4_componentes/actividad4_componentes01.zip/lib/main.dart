import 'package:actividad4_componentes/routers/app_routers.dart';
import 'package:actividad4_componentes/theme/app_themes.dart';
import 'package:flutter/material.dart';

void main() {
  runApp(const MyApp());
}

class MyApp extends StatelessWidget {
  const MyApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'Flutter Demo',
      //Controla la visualización de la pancarta de depuración en la 
      //esquina superior derecha de la aplicación en modo de depuración.
      debugShowCheckedModeBanner: false,
      //Establece el tema de la aplicación
      theme: AppThemes.themes,
      //Define la ruta inicial de la aplicación
      initialRoute: AppRouters.initialRouters,
      // home: const ListViewBuildScreen(),
      routes:AppRouters.routes,
    );
  }
}
