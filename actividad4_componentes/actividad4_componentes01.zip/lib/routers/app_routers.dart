
import 'package:flutter/material.dart';
import '../screen/screen.dart';

class AppRouters{
  //Esta línea declara una variable estática llamada routes que es un mapa
  //cuyas claves son cadenas de texto y los valores son funciones que toman un contexto de tipo BuildContext y devuelven un StatelessWidget.
  static Map<String, StatelessWidget Function(BuildContext context)> routes = {

        //Establecer la pantalla principal de la aplicación cuando se accede a la ruta raíz ('/').
        '/':(BuildContext context) => const HomeScreen(),
        //Define una ruta llamada '/ListView' que muestra la pantalla ListViewBuildScreen. Cuando la aplicación navega a '/ListView', 
        //se crea una instancia de ListViewBuildScreen y se muestra en la pantalla.
        '/ListView':(BuildContext context) => const ListViewBuildScreen(),
        //Define una ruta llamada '/Jugador' que muestra la pantalla JugadorScreen. 
        //Cuando la aplicación navega a '/Jugador', se crea una instancia de JugadorScreen y se muestra en la pantalla.
        '/Jugador':(BuildContext context) => const JugadorScreen(),
        //define una ruta llamada '/Equipos' que muestra la pantalla EquipoScreen. 
        //Cuando la aplicación navega a '/Equipos', 
        //se crea una instancia de EquipoScreen y se muestra en la pantalla.
        '/Equipos':(BuildContext context) => const EquipoScreen()
      };
  //Establece la ruta inicial de la aplicación en '/'.
  static String initialRouters='/';
}

