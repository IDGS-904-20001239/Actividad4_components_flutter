import 'package:flutter/material.dart';
import 'package:flutter/services.dart';

class HomeScreen extends StatelessWidget {
   
  const HomeScreen({Key? key}) : super(key: key);
  
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      //Barra de arriba de la aplicación. El title ocupa un wiget de tipo text
      appBar: AppBar(title: const Center(child: Text("Actividad 4"))),
      //Forma sencilla de hacer listas
      // mostrar una lista de elementos. Los elementos de la lista se definen como un 
      //conjunto de widgets ListTile, que incluyen un ícono, un título y un subtítulo.
      body: ListView(children:[
        ListTile(leading:Icon(Icons.list_alt_outlined),
        subtitle: Text("Esta es una pagina de ListView Build"),
        title: Text("List View Build"),
        onTap: () {
          //Se utiliza Navigator.pushNamed para navegar a la ruta '/ListView'
          Navigator.pushNamed(context, '/ListView');
          print("Acabo de dar un Tap en el ListView Build");
        }),
      //Mostrar una lista de elementos. Los elementos de la lista se definen como un 
      //conjunto de widgets ListTile, que incluyen un ícono, un título y un subtítulo.
        ListTile(leading:Icon(Icons.list_alt_outlined),
        subtitle: Text("Esta es una pagina de Jugadores"),
        title: Text("Jugadores"),
        onTap: () {
          //Se utiliza Navigator.pushNamed para navegar a la ruta '/Jugador'
          Navigator.pushNamed(context, '/Jugador');
        }),
      //Mostrar una lista de elementos. Los elementos de la lista se definen como un 
      //conjunto de widgets ListTile, que incluyen un ícono, un título y un subtítulo.
        ListTile(leading:Icon(Icons.list_alt_outlined),
        subtitle: Text("Esta es una pagina de Equipos"),
        title: Text("Equipos"),
        onTap: () {
          //Se utiliza Navigator.pushNamed para navegar a la ruta '/Equipos'
          Navigator.pushNamed(context, '/Equipos');
        })
       
      ],
      ),
      
    );
  }
}